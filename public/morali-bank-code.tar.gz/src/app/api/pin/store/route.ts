import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { rateLimit, getClientId } from "@/lib/rate-limit";
import { requireAuth } from "@/lib/auth-verify";
import { createHash } from "crypto";

export async function POST(req: NextRequest) {
  const clientId = getClientId(req);
  const rl = rateLimit(`pin:store:${clientId}`, { maxRequests: 10, windowSec: 60 });
  if (!rl.allowed) {
    return NextResponse.json({ error: "Trop de requêtes" }, { status: 429 });
  }

  const auth = await requireAuth(req);
  if (auth.error) return auth.error;
  if (!auth.uid) return NextResponse.json({ error: "Non autorisé" }, { status: 401 });

  try {
    const body = await req.json();
    const { pin } = body;

    if (!pin || !/^\d{4}$/.test(pin)) {
      return NextResponse.json({ error: "Code PIN invalide" }, { status: 400 });
    }

    const salt = createHash("sha256").update(`${auth.uid}:${Date.now()}`).digest("hex").slice(0, 32);
    const pinHash = createHash("sha256").update(`${salt}:${pin}`).digest("hex");

    await db.pinRecord.upsert({
      where: { uid: auth.uid },
      create: { uid: auth.uid, pinHash, salt },
      update: { pinHash, salt },
    });

    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Erreur interne" }, { status: 500 });
  }
}
