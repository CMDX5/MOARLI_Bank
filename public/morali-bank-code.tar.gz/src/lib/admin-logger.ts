/**
 * Persist admin activity to SQLite for audit trail.
 * Replaces the in-memory-only logAdminActivity.
 */
export async function logAdminActivityDB(action: string, details: string): Promise<void> {
  try {
    await fetch("/api/admin/log", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action, details }),
    });
  } catch {
    // Silent fail — logging should never break the app
  }
}
