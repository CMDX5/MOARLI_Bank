import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { rateLimit, getClientId } from "@/lib/rate-limit";
import { requireAuth } from "@/lib/auth-verify";

/**
 * Directory Search API
 * 
 * Security:
 * - Rate limited (40 searches/min)
 * - Input validation (prevent injection)
 * - Query length limits
 * - Sanitized output
 */
export async function GET(req: NextRequest) {
  // ── Rate limit: 40 searches/min ──
  const clientId = getClientId(req);
  const rl = rateLimit(`directory:search:${clientId}`, { maxRequests: 40, windowSec: 60 });
  if (!rl.allowed) {
    return NextResponse.json({ error: "Trop de requêtes" }, {
      status: 429,
      headers: { "Retry-After": String(Math.ceil((rl.resetAt - Date.now()) / 1000)) },
    });
  }

    const auth = await requireAuth(req);
    if (auth.error) return auth.error;
    if (!auth.uid) return NextResponse.json({ found: false }, { status: 401 });

  try {
    const rawQuery = req.nextUrl.searchParams.get("q") || "";
    const query = rawQuery.trim();

    // Validate query
    if (!query || query.length < 2) {
      return NextResponse.json({ found: false });
    }

    // Limit query length (prevent abuse)
    if (query.length > 100) {
      return NextResponse.json({ found: false, error: "Requête trop longue" }, { status: 400 });
    }

    // Sanitize: only allow alphanumeric + @
    const sanitizedQuery = query.replace(/[^a-zA-Z0-9@._-]/g, "");
    if (!sanitizedQuery || sanitizedQuery.length < 2) {
      return NextResponse.json({ found: false });
    }

    const normalizedMoraliId = sanitizedQuery.toUpperCase().replace(/[^A-Z0-9]/g, "");
    const normalizedPseudo = sanitizedQuery.toLowerCase().replace(/^@/, "").replace(/[^a-z0-9]/g, "");

    // Search by moraliId
    if (normalizedMoraliId.startsWith("MORALI")) {
      // Validate format
      if (!/^MORALI\d{1,20}$/.test(normalizedMoraliId)) {
        return NextResponse.json({ found: false });
      }

      const user = await db.moraliDirectory.findFirst({
        where: { moraliIdNormalized: normalizedMoraliId },
      });

      if (user) {
        return NextResponse.json({
          found: true,
          name: user.fullName,
          pseudo: user.pseudo.startsWith("@") ? user.pseudo : `@${user.pseudo}`,
          account: user.moraliId,
          uid: user.uid,
        });
      }
    }

    // Search by pseudo
    if (normalizedPseudo.length >= 2) {
      const user = await db.moraliDirectory.findFirst({
        where: { pseudoNormalized: normalizedPseudo },
      });

      if (user) {
        return NextResponse.json({
          found: true,
          name: user.fullName,
          pseudo: user.pseudo.startsWith("@") ? user.pseudo : `@${user.pseudo}`,
          account: user.moraliId,
          uid: user.uid,
        });
      }
    }

    // Not found — return generic response (don't reveal if user exists)
    return NextResponse.json({ found: false });
  } catch (err) {
    console.error("[directory:search] Operation failed");
    return NextResponse.json({ found: false, error: "search_failed" });
  }
}
