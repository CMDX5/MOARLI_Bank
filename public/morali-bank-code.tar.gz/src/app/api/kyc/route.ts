import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { rateLimit, getClientId } from "@/lib/rate-limit";
import { requireAuth } from "@/lib/auth-verify";

// POST: Submit KYC documents
export async function POST(req: NextRequest) {
  const clientId = getClientId(req);
  const rl = rateLimit(`kyc:submit:${clientId}`, { maxRequests: 5, windowSec: 60 });
  if (!rl.allowed) {
    return NextResponse.json({ error: "Trop de requêtes" }, {
      status: 429,
      headers: { "Retry-After": String(Math.ceil((rl.resetAt - Date.now()) / 1000)) },
    });
  }

  const auth = await requireAuth(req);
  if (auth.error) return auth.error;
  if (!auth.uid) return NextResponse.json({ error: "Non autorisé" }, { status: 401 });

  try {
    const body = await req.json();
    const { documentType, documentFront, documentBack, selfiePhoto, fullName, dateOfBirth, documentNumber } = body;

    // Validation
    if (!documentType || !documentFront || !fullName) {
      return NextResponse.json({ error: "Champs requis manquants" }, { status: 400 });
    }

    const validTypes = ["national_id", "passport", "driver_license"];
    if (!validTypes.includes(documentType)) {
      return NextResponse.json({ error: "Type de document invalide" }, { status: 400 });
    }

    // Validate image size (max 5MB base64 = ~7MB raw)
    const MAX_SIZE = 7_000_000;
    if (documentFront.length > MAX_SIZE) {
      return NextResponse.json({ error: "Image recto trop volumineuse (max 5 MB)" }, { status: 400 });
    }

    // Upsert KYC record
    const record = await db.kycRecord.upsert({
      where: { uid: auth.uid },
      create: {
        uid: auth.uid,
        status: "submitted",
        documentType: String(documentType).slice(0, 30),
        documentFront: String(documentFront).slice(0, 10_000_000),
        documentBack: documentBack ? String(documentBack).slice(0, 10_000_000) : null,
        selfiePhoto: selfiePhoto ? String(selfiePhoto).slice(0, 10_000_000) : null,
        fullName: String(fullName).slice(0, 100),
        dateOfBirth: dateOfBirth ? String(dateOfBirth).slice(0, 20) : null,
        documentNumber: documentNumber ? String(documentNumber).slice(0, 50) : null,
        submittedAt: new Date(),
      },
      update: {
        status: "submitted",
        documentType: String(documentType).slice(0, 30),
        documentFront: String(documentFront).slice(0, 10_000_000),
        documentBack: documentBack ? String(documentBack).slice(0, 10_000_000) : null,
        selfiePhoto: selfiePhoto ? String(selfiePhoto).slice(0, 10_000_000) : null,
        fullName: String(fullName).slice(0, 100),
        dateOfBirth: dateOfBirth ? String(dateOfBirth).slice(0, 20) : null,
        documentNumber: documentNumber ? String(documentNumber).slice(0, 50) : null,
        submittedAt: new Date(),
        reviewedAt: null,
        reviewerNotes: null,
      },
    });

    return NextResponse.json({ success: true, status: record.status });
  } catch {
    return NextResponse.json({ error: "Erreur interne" }, { status: 500 });
  }
}

// GET: Get KYC status for current user
export async function GET(req: NextRequest) {
  const auth = await requireAuth(req);
  if (auth.error) return auth.error;
  if (!auth.uid) return NextResponse.json({ error: "Non autorisé" }, { status: 401 });

  try {
    const record = await db.kycRecord.findUnique({
      where: { uid: auth.uid },
      select: {
        status: true,
        documentType: true,
        submittedAt: true,
        reviewedAt: true,
        reviewerNotes: true,
        // Don't return document images in the status check
      },
    });

    return NextResponse.json({
      verified: record?.status === "approved",
      status: record?.status || "none",
      documentType: record?.documentType || null,
      submittedAt: record?.submittedAt || null,
      reviewedAt: record?.reviewedAt || null,
      reviewerNotes: record?.reviewerNotes || null,
    });
  } catch {
    return NextResponse.json({ verified: false, status: "none" });
  }
}
