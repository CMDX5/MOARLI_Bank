import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { rateLimit, getClientId } from "@/lib/rate-limit";
import { requireAuth } from "@/lib/auth-verify";

export async function GET(req: NextRequest) {
  // Rate limit
  const clientId = getClientId(req);
  const rl = rateLimit(`tx:list:${clientId}`, { maxRequests: 60, windowSec: 60 });
  if (!rl.allowed) {
    return NextResponse.json(
      { error: "Trop de requêtes. Réessayez plus tard." },
      { status: 429, headers: { "Retry-After": String(Math.ceil((rl.resetAt - Date.now()) / 1000)) } }
    );
  }

  // Auth
  const auth = await requireAuth(req);
  if (auth.error) return auth.error;

  const uid = req.nextUrl.searchParams.get("uid");
  if (!uid || uid.length > 128) {
    return NextResponse.json({ error: "UID requis" }, { status: 400 });
  }

  // Ownership: user can only read their own transactions
  if (uid !== auth.uid) {
    return NextResponse.json({ error: "Non autorisé" }, { status: 403 });
  }

  try {
    const limit = Math.min(Number(req.nextUrl.searchParams.get("limit") || 50), 100);

    // Get transactions where user is sender OR recipient
    const sent = await db.transactionRecord.findMany({
      where: { senderUid: uid },
      orderBy: { createdAt: "desc" },
      take: limit,
    });

    const received = await db.transactionRecord.findMany({
      where: { recipientUid: uid },
      orderBy: { createdAt: "desc" },
      take: limit,
    });

    // Merge, deduplicate, sort by date
    const all = [...sent, ...received];
    const unique = new Map<string, typeof all[0]>();
    for (const tx of all) {
      if (!unique.has(tx.id)) unique.set(tx.id, tx);
    }
    const sorted = [...unique.values()].sort(
      (a, b) => b.createdAt.getTime() - a.createdAt.getTime()
    );

    return NextResponse.json({ transactions: sorted });
  } catch {
    return NextResponse.json({ transactions: [] }, { status: 200 });
  }
}
