import { isFirebaseConfigured } from "../lib/firebase";

export function getFirebaseStatus() {
  return {
    configured: isFirebaseConfigured,
    message: isFirebaseConfigured
      ? "Firebase prêt à être utilisé."
      : "Firebase installé mais non configuré. Ajoutez vos variables VITE_FIREBASE_*.",
  };
}
