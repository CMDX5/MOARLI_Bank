import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { rateLimit, getClientId } from "@/lib/rate-limit";
import { requireAuth } from "@/lib/auth-verify";

/**
 * Pending Credit API Routes
 * 
 * Security:
 * - Rate limited per endpoint
 * - Input validation & sanitization
 * - Amount bounds checking
 * - Uses shared db singleton (not new PrismaClient)
 */

// GET: Fetch pending credits for a recipient
export async function GET(req: NextRequest) {
  // ── Rate limit: 60 reads/min ──
  const clientId = getClientId(req);
  const rl = rateLimit(`pending-credit:GET:${clientId}`, { maxRequests: 60, windowSec: 60 });
  if (!rl.allowed) {
    return NextResponse.json({ error: "Trop de requêtes" }, {
      status: 429,
      headers: { "Retry-After": String(Math.ceil((rl.resetAt - Date.now()) / 1000)) },
    });
  }

  const auth = await requireAuth(req);
  if (auth.error) return auth.error;
  if (!auth.uid) return NextResponse.json({ error: "Non autorisé" }, { status: 401 });

  try {
    const uid = req.nextUrl.searchParams.get("uid");
    if (!uid) {
      return NextResponse.json({ error: "Paramètre uid requis" }, { status: 400 });
    }

    // Ownership check: can only fetch own pending credits
    if (uid !== auth.uid) {
      return NextResponse.json({ error: "Accès refusé" }, { status: 403 });
    }

    // Sanitize uid — must be Firebase UID format
    if (!/^[a-zA-Z0-9_-]{1,128}$/.test(uid)) {
      return NextResponse.json({ error: "Identifiant invalide" }, { status: 400 });
    }

    const pendingCredits = await db.pendingCredit.findMany({
      where: { recipientUid: uid },
      orderBy: { createdAt: "asc" },
      // Limit results to prevent abuse
      take: 100,
    });

    return NextResponse.json({ credits: pendingCredits });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error("[pending-credit:GET]", msg);
    return NextResponse.json({ error: "Erreur interne du serveur" }, { status: 500 });
  }
}

// POST: Create a new pending credit
export async function POST(req: NextRequest) {
  // ── Rate limit: 20 writes/min ──
  const clientId = getClientId(req);
  const rl = rateLimit(`pending-credit:POST:${clientId}`, { maxRequests: 20, windowSec: 60 });
  if (!rl.allowed) {
    return NextResponse.json({ error: "Trop de requêtes" }, {
      status: 429,
      headers: { "Retry-After": String(Math.ceil((rl.resetAt - Date.now()) / 1000)) },
    });
  }

  const auth = await requireAuth(req);
  if (auth.error) return auth.error;
  if (!auth.uid) return NextResponse.json({ error: "Non autorisé" }, { status: 401 });

  try {
    let body: { recipientUid?: string; amount?: number; senderName?: string; senderMoraliId?: string; receiptId?: string };
    try {
      body = await req.json();
    } catch {
      return NextResponse.json({ error: "Corps de requête invalide" }, { status: 400 });
    }

    const { recipientUid, amount, senderName, senderMoraliId, receiptId } = body;

    // ── Validation ──
    if (!recipientUid || amount === undefined || amount === null) {
      return NextResponse.json({ error: "Paramètres manquants" }, { status: 400 });
    }

    // Validate uid format
    if (!/^[a-zA-Z0-9_-]{1,128}$/.test(recipientUid)) {
      return NextResponse.json({ error: "Identifiant destinataire invalide" }, { status: 400 });
    }

    // Validate amount bounds
    const numericAmount = Number(amount);
    if (!Number.isFinite(numericAmount) || numericAmount <= 0) {
      return NextResponse.json({ error: "Montant invalide" }, { status: 400 });
    }
    if (numericAmount > 50_000_000) {
      return NextResponse.json({ error: "Montant exceeds la limite (50M FCFA)" }, { status: 400 });
    }

    // Sanitize string inputs (prevent XSS/NoSQL injection)
    const sanitize = (s: string, maxLen: number) =>
      String(s || "").slice(0, maxLen).replace(/[<>'"&]/g, "");

    const credit = await db.pendingCredit.create({
      data: {
        recipientUid,
        amount: Math.round(numericAmount),
        senderName: sanitize(senderName, 100),
        senderMoraliId: sanitize(senderMoraliId, 50),
        receiptId: sanitize(receiptId, 50),
      },
    });

    return NextResponse.json({ success: true, credit });
  } catch (err) {
    console.error("[pending-credit:POST] Operation failed");
    return NextResponse.json({ error: "Erreur interne du serveur" }, { status: 500 });
  }
}

// DELETE: Delete a pending credit by id
export async function DELETE(req: NextRequest) {
  // ── Rate limit: 30 deletes/min ──
  const clientId = getClientId(req);
  const rl = rateLimit(`pending-credit:DELETE:${clientId}`, { maxRequests: 30, windowSec: 60 });
  if (!rl.allowed) {
    return NextResponse.json({ error: "Trop de requêtes" }, {
      status: 429,
      headers: { "Retry-After": String(Math.ceil((rl.resetAt - Date.now()) / 1000)) },
    });
  }

  const auth = await requireAuth(req);
  if (auth.error) return auth.error;
  if (!auth.uid) return NextResponse.json({ error: "Non autorisé" }, { status: 401 });

  try {
    let body: { id?: string };
    try {
      body = await req.json();
    } catch {
      return NextResponse.json({ error: "Corps de requête invalide" }, { status: 400 });
    }

    const { id } = body;
    if (!id) {
      return NextResponse.json({ error: "Paramètre id requis" }, { status: 400 });
    }

    // Validate id format (cuid)
    if (!/^[a-zA-Z0-9_-]{1,128}$/.test(id)) {
      return NextResponse.json({ error: "Identifiant invalide" }, { status: 400 });
    }

    await db.pendingCredit.delete({ where: { id } });

    return NextResponse.json({ success: true });
  } catch (err) {
    console.error("[pending-credit:DELETE] Operation failed");
    return NextResponse.json({ error: "Erreur interne du serveur" }, { status: 500 });
  }
}
