#!/bin/bash
# ============================================
# Morali Bank - Migration Script: SQLite → PostgreSQL
# ============================================
# This script migrates the Morali Bank database from SQLite to PostgreSQL (Supabase).
#
# PREREQUISITES:
#   1. You must have replaced [YOUR-PASSWORD] in .env.production with your real Supabase password
#   2. You must have the real Firebase Admin SDK key in service-account-key.json
#
# USAGE:
#   chmod +x scripts/migrate-to-supabase.sh
#   ./scripts/migrate-to-supabase.sh
# ============================================

set -e

echo "============================================"
echo "  Morali Bank - Migration vers Supabase"
echo "============================================"
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Check if .env.production exists
if [ ! -f ".env.production" ]; then
    echo -e "${RED}ERREUR: .env.production not found!${NC}"
    exit 1
fi

# Check if password is still placeholder
if grep -q "\[YOUR-PASSWORD\]" .env.production; then
    echo -e "${RED}ERREUR: DATABASE_URL still contains [YOUR-PASSWORD] placeholder!${NC}"
    echo ""
    echo "Please edit .env.production and replace [YOUR-PASSWORD] with your actual Supabase database password."
    echo "You can find it in: Supabase Dashboard → Settings → Database"
    echo ""
    exit 1
fi

# Check if service account has placeholder
if grep -q "\[REPLACE" service-account-key.json 2>/dev/null; then
    echo -e "${YELLOW}ATTENTION: service-account-key.json still has placeholder values.${NC}"
    echo "Firebase Admin SDK won't work until you replace the private_key with the real key."
    echo ""
    read -p "Continue anyway? (y/n) " -n 1 -r
    echo ""
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

echo -e "${GREEN}Step 1/5: Installing PostgreSQL dependency...${NC}"
npm install pg --save 2>/dev/null || bun add pg

echo ""
echo -e "${GREEN}Step 2/5: Switching Prisma schema to PostgreSQL...${NC}"
cp prisma/schema.postgresql.prisma prisma/schema.prisma
echo "Schema switched to PostgreSQL."

echo ""
echo -e "${GREEN}Step 3/5: Generating Prisma client for PostgreSQL...${NC}"
npx prisma generate 2>/dev/null || bunx prisma generate

echo ""
echo -e "${GREEN}Step 4/5: Pushing schema to Supabase PostgreSQL...${NC}"
# Use the DATABASE_URL from .env.production
DATABASE_URL=$(grep "^DATABASE_URL=" .env.production | cut -d'"' -f2)
DATABASE_URL="$DATABASE_URL" npx prisma db push --accept-data-loss 2>/dev/null || DATABASE_URL="$DATABASE_URL" bunx prisma db push --accept-data-loss

echo ""
echo -e "${GREEN}Step 5/5: Verifying connection...${NC}"
DATABASE_URL="$DATABASE_URL" node -e "
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
prisma.\$queryRaw\\\`SELECT 1 as test\\\`.then(r => {
    console.log('PostgreSQL connection: OK');
    prisma.\$disconnect();
}).catch(e => {
    console.error('PostgreSQL connection FAILED:', e.message);
    process.exit(1);
});
"

echo ""
echo "============================================"
echo -e "${GREEN}  Migration complete!${NC}"
echo "============================================"
echo ""
echo "Next steps:"
echo "  1. Deploy to Vercel/Railway with the env vars from .env.production"
echo "  2. Verify: curl https://[YOUR-DOMAIN]/api/health"
echo ""
