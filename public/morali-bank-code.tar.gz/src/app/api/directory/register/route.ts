import { NextRequest, NextResponse } from "next/server";
import { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { rateLimit, getClientId } from "@/lib/rate-limit";
import { requireAuth } from "@/lib/auth-verify";

/**
 * Directory Registration API
 * 
 * Security:
 * - Rate limited (15 writes/min)
 * - Input validation & sanitization
 * - String length limits
 * - XSS prevention
 */
export async function POST(req: NextRequest) {
  // ── Rate limit: 15 registrations/min ──
  const clientId = getClientId(req);
  const rl = rateLimit(`directory:register:${clientId}`, { maxRequests: 15, windowSec: 60 });
  if (!rl.allowed) {
    return NextResponse.json({ error: "Trop de requêtes" }, {
      status: 429,
      headers: { "Retry-After": String(Math.ceil((rl.resetAt - Date.now()) / 1000)) },
    });
  }

  const auth = await requireAuth(req);
  if (auth.error) return auth.error;
  if (!auth.uid) return NextResponse.json({ error: "Non autorisé" }, { status: 401 });

  try {
    let body: {
      uid?: string;
      moraliId?: string;
      pseudo?: string;
      fullName?: string;
      firstName?: string;
      lastName?: string;
    };

    try {
      body = await req.json();
    } catch {
      return NextResponse.json({ error: "Corps de requête invalide" }, { status: 400 });
    }

    const { uid, moraliId, pseudo, fullName, firstName, lastName } = body;

    // Auth: user can only register themselves
    if (uid !== auth.uid) {
      return NextResponse.json({ error: "Non autorisé" }, { status: 403 });
    }

    // ── Validation ──
    if (!uid || !moraliId) {
      return NextResponse.json({ error: "Paramètres uid et moraliId requis" }, { status: 400 });
    }

    // Validate uid format (Firebase UID)
    if (!/^[a-zA-Z0-9_-]{1,128}$/.test(uid)) {
      return NextResponse.json({ error: "Format uid invalide" }, { status: 400 });
    }

    // Validate moraliId format (MORALI + digits)
    const moraliIdNormalized = moraliId.toUpperCase().replace(/[^A-Z0-9]/g, "");
    if (!/^MORALI\d{1,20}$/.test(moraliIdNormalized)) {
      return NextResponse.json({ error: "Format identifiant Morali invalide" }, { status: 400 });
    }

    // Sanitize pseudo
    const pseudoClean = (pseudo || "").toLowerCase().replace(/^@/, "").replace(/[^a-z0-9]/g, "");
    if (pseudoClean.length > 20) {
      return NextResponse.json({ error: "Pseudo trop long (max 20 caractères)" }, { status: 400 });
    }

    // Sanitize name fields (prevent XSS, limit length)
    const sanitize = (s: string, maxLen: number) =>
      String(s || "").slice(0, maxLen).replace(/[<>'"&]/g, "").trim();

    const safeFullName = sanitize(fullName, 100) || "Utilisateur";
    const safeFirstName = sanitize(firstName, 50);
    const safeLastName = sanitize(lastName, 50);

    try {
      const record = await db.moraliDirectory.upsert({
        where: { uid },
        create: {
          uid,
          moraliId: moraliIdNormalized,
          moraliIdNormalized,
          pseudo: pseudoClean,
          pseudoNormalized: pseudoClean,
          fullName: safeFullName,
          firstName: safeFirstName,
          lastName: safeLastName,
        },
        update: {
          moraliId: moraliIdNormalized,
          moraliIdNormalized,
          pseudo: pseudoClean,
          pseudoNormalized: pseudoClean,
          fullName: safeFullName,
          firstName: safeFirstName,
          lastName: safeLastName,
        },
      });

      // Don't return internal data in response
      return NextResponse.json({ success: true });
    } catch (upsertErr) {
      if (upsertErr instanceof Prisma.PrismaClientKnownRequestError && upsertErr.code === "P2002") {
        // Unique constraint conflict — delete old and recreate
        await db.moraliDirectory.deleteMany({ where: { uid } });
        const record = await db.moraliDirectory.create({
          data: {
            uid,
            moraliId: moraliIdNormalized,
            moraliIdNormalized,
            pseudo: pseudoClean,
            pseudoNormalized: pseudoClean,
            fullName: safeFullName,
            firstName: safeFirstName,
            lastName: safeLastName,
          },
        });
        return NextResponse.json({ success: true });
      }
      throw upsertErr;
    }
  } catch (err) {
    console.error("[directory:register] Operation failed");
    return NextResponse.json({ error: "Erreur interne du serveur" }, { status: 500 });
  }
}
