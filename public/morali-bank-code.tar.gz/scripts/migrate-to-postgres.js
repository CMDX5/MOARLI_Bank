/**
 * SQLite to PostgreSQL Migration Script
 * 
 * Usage: node scripts/migrate-to-postgres.js
 * 
 * This script reads data from the SQLite database and inserts it into PostgreSQL.
 * Run this AFTER switching to PostgreSQL schema and running `prisma db push`.
 * 
 * Prerequisites:
 * - DATABASE_URL must point to PostgreSQL
 * - SQLite database must exist at db/custom.db
 */

const { PrismaClient } = require("@prisma/client");

async function migrate() {
  const sourceDb = new PrismaClient({
    datasources: {
      db: { url: "file:./db/custom.db" },
    },
  });

  const targetDb = new PrismaClient();

  try {
    console.log("[MIGRATE] Starting migration from SQLite to PostgreSQL...\n");

    // 1. Migrate MoraliDirectory
    console.log("[1/7] Migrating MoraliDirectory...");
    const directories = await sourceDb.moraliDirectory.findMany();
    console.log("   Found " + directories.length + " records");

    for (const dir of directories) {
      await targetDb.moraliDirectory.upsert({
        where: { uid: dir.uid },
        create: { ...dir },
        update: { ...dir },
      });
    }
    console.log("   OK Migrated " + directories.length + " directory entries\n");

    // 2. Migrate PendingCredits
    console.log("[2/7] Migrating PendingCredits...");
    const credits = await sourceDb.pendingCredit.findMany();
    console.log("   Found " + credits.length + " records");

    for (const credit of credits) {
      await targetDb.pendingCredit.create({ data: { ...credit } });
    }
    console.log("   OK Migrated " + credits.length + " pending credits\n");

    // 3. Migrate TransactionRecords
    console.log("[3/7] Migrating TransactionRecords...");
    const transactions = await sourceDb.transactionRecord.findMany();
    console.log("   Found " + transactions.length + " records");

    for (const tx of transactions) {
      await targetDb.transactionRecord.create({ data: { ...tx } });
    }
    console.log("   OK Migrated " + transactions.length + " transactions\n");

    // 4. Migrate NotificationRecords
    console.log("[4/7] Migrating NotificationRecords...");
    const notifications = await sourceDb.notificationRecord.findMany();
    console.log("   Found " + notifications.length + " records");

    for (const notif of notifications) {
      await targetDb.notificationRecord.create({ data: { ...notif } });
    }
    console.log("   OK Migrated " + notifications.length + " notifications\n");

    // 5. Migrate PinRecords
    console.log("[5/7] Migrating PinRecords...");
    const pins = await sourceDb.pinRecord.findMany();
    console.log("   Found " + pins.length + " records");

    for (const pin of pins) {
      await targetDb.pinRecord.upsert({
        where: { uid: pin.uid },
        create: { ...pin },
        update: { ...pin },
      });
    }
    console.log("   OK Migrated " + pins.length + " PIN records\n");

    // 6. Migrate AdminActivity
    console.log("[6/7] Migrating AdminActivity...");
    const activities = await sourceDb.adminActivity.findMany();
    console.log("   Found " + activities.length + " records");

    for (const activity of activities) {
      await targetDb.adminActivity.create({ data: { ...activity } });
    }
    console.log("   OK Migrated " + activities.length + " admin activities\n");

    // 7. Migrate KycRecord
    console.log("[7/7] Migrating KycRecord...");
    const kycRecords = await sourceDb.kycRecord.findMany();
    console.log("   Found " + kycRecords.length + " records");

    for (const kyc of kycRecords) {
      await targetDb.kycRecord.upsert({
        where: { uid: kyc.uid },
        create: { ...kyc },
        update: { ...kyc },
      });
    }
    console.log("   OK Migrated " + kycRecords.length + " KYC records\n");

    console.log("[MIGRATE] Migration complete! All data transferred.");

  } catch (error) {
    console.error("[MIGRATE] Failed:", error.message);
    process.exit(1);
  } finally {
    await sourceDb.$disconnect();
    await targetDb.$disconnect();
  }
}

migrate();
