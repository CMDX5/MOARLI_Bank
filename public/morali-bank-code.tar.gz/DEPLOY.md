# 🚀 Guide de Déploiement — Morali Bank

## Architecture de production

```
[Vercel / Railway / VPS]
    ├── Next.js App (HTTPS automatique)
    ├── PostgreSQL (Supabase / Neon)
    ├── Firebase Auth + Firestore (existant)
    └── Firebase Admin SDK (nouveau)
```

## Étape 1 — Créer une base de données PostgreSQL (gratuit)

### Option A: Supabase (recommandé)
1. Aller sur https://supabase.com
2. Créer un compte gratuit
3. Créer un nouveau projet
4. Aller dans Settings → Database
5. Copier la "Connection string" au format PostgreSQL
6. Elle ressemble à: `postgresql://postgres:[PASSWORD]@db.[PROJECT_REF].supabase.co:5432/postgres`

### Option B: Neon (alternative)
1. Aller sur https://neon.tech
2. Créer un projet gratuit
3. Copier la connexion PostgreSQL

## Étape 2 — Activer Firebase Admin SDK

1. Aller sur https://console.firebase.google.com
2. Sélectionner le projet "banque-digitale"
3. Cliquez sur l'icône ⚙️ (Paramètres du projet) → Comptes de service
4. Cliquez sur "Générer une nouvelle clé privée"
5. Télécharger le fichier JSON
6. **NE JAMAIS** commit ce fichier dans Git !
7. Le contenu ressemble à:
```json
{
  "type": "service_account",
  "project_id": "banque-digitale",
  "private_key_id": "...",
  "private_key": "-----BEGIN PRIVATE KEY-----\n...\n-----END PRIVATE KEY-----\n",
  "client_email": "firebase-adminsdk-...@banque-digitale.iam.gserviceaccount.com",
  ...
}
```

## Étape 3 — Configurer les variables d'environnement

Sur votre plateforme d'hébergement (Vercel, Railway, etc.), ajoutez ces variables:

```env
# Base de données PostgreSQL
DATABASE_URL="postgresql://postgres:[PASSWORD]@db.[REF].supabase.co:5432/postgres"

# Firebase Admin SDK (coller le contenu JSON complet sur UNE SEULE ligne)
GOOGLE_APPLICATION_CREDENTIALS='{"type":"service_account","project_id":"banque-digitale",...}'

# Firebase (déjà existant)
NEXT_PUBLIC_FIREBASE_API_KEY="AIzaSyBTgQjc1zJvPSAZZ0VDZD0PLZRPFCw9Zlc"
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN="banque-digitale.firebaseapp.com"
NEXT_PUBLIC_FIREBASE_PROJECT_ID="banque-digitale"
```

## Étape 4 — Switch SQLite → PostgreSQL

### Méthode automatique (recommandée):
```bash
# Sur votre machine locale
cp prisma/schema.postgresql.prisma prisma/schema.prisma
npx prisma generate
npx prisma db push
```

### Méthode manuelle:
1. Ouvrir `prisma/schema.prisma`
2. Remplacer `provider = "sqlite"` par `provider = "postgresql"`
3. Remplacer `url = env("DATABASE_URL")` par `url = env("DATABASE_URL")` (déjà correct)
4. Supprimer les lignes `@default(autoincrement())` si présentes (PostgreSQL utilise SERIAL)
5. Sauvegarder et lancer `npx prisma generate && npx prisma db push`

## Étape 5 — Migrer les données existantes (optionnel)

Si vous avez des données en SQLite à migrer vers PostgreSQL:

```bash
# Exécuter le script de migration
node scripts/migrate-to-postgres.js
```

Ce script lit la base SQLite et insère les données dans PostgreSQL.

## Étape 6 — Déployer

### Option A: Vercel (le plus simple)
1. Pousser le code sur GitHub
2. Aller sur https://vercel.com
3. Importer le repository
4. Ajouter les variables d'environnement (Étape 3)
5. Déployer → HTTPS automatique avec Let's Encrypt

### Option B: Railway
1. Aller sur https://railway.app
2. Créer un nouveau projet
3. Connecter GitHub
4. Ajouter un service PostgreSQL (Railway le fournit)
5. Mettre à jour DATABASE_URL avec l'URL Railway
6. Déployer

### Option C: VPS (Ubuntu)
```bash
# Sur votre serveur
sudo apt update && sudo apt install -y nginx certbot postgresql
# Configurer NGINX + Let's Encrypt
# Installer Node.js 20+
git clone [votre-repo]
cd morali-bank
npm install
npm run build
pm2 start npm --name "morali-bank" -- start
```

## Étape 7 — Vérifier le déploiement

```bash
# Health check
curl https://[VOTRE-DOMAINE]/api/health

# Doit retourner:
# {
#   "status": "healthy",
#   "database": "postgresql",
#   "checks": { "database": { "status": "ok" }, ... }
# }

# Vérifier que l'auth est sécurisé (RS256)
# Le endpoint /api/health doit montrer firebase.status = "ok"
```

## Checklist de production

- [ ] Base de données PostgreSQL créée et connectée
- [ ] Firebase Admin SDK configuré (GOOGLE_APPLICATION_CREDENTIALS)
- [ ] Variables d'environnement ajoutées sur l'hébergement
- [ ] Schema Prisma switché vers PostgreSQL
- [ ] `prisma db push` exécuté avec succès
- [ ] HTTPS actif (certificat SSL)
- [ ] `/api/health` retourne "healthy"
- [ ] Test de connexion: login, virement, dépôt, retrait
- [ ] Sauvegarde automatique configurée (cron)
- [ ] Domaine personnalisé configuré

## Sécurité en production

- [ ] GOOGLE_APPLICATION_CREDENTIALS n'est JAMAIS commit dans Git
- [ ] Les secrets sont dans les variables d'environnement
- [ ] HTTPS forcé (redirect HTTP → HTTPS)
- [ ] Rate limiting actif sur toutes les routes API
- [ ] PIN stocké côté serveur (jamais côté client)
- [ ] Firestore rules déployées sur Firebase Console
