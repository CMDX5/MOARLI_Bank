import { NextResponse } from "next/server";
import { existsSync, statSync } from "fs";
import path from "path";
import { PrismaClient } from "@prisma/client";

/**
 * GET /api/health — Production health check endpoint.
 * Returns system status for monitoring tools.
 * Detects SQLite vs PostgreSQL based on DATABASE_URL format.
 */
export async function GET() {
  const startTime = Date.now();

  const checks: Record<string, { status: "ok" | "degraded" | "error"; detail?: string }> = {};

  // Determine database type from DATABASE_URL
  const dbUrl = process.env.DATABASE_URL || "";
  const isPostgres = dbUrl.startsWith("postgresql://") || dbUrl.startsWith("postgres://");
  const isSqlite = dbUrl.startsWith("file:");

  // Database check
  try {
    if (isPostgres) {
      // PostgreSQL — run a lightweight query via Prisma
      const prisma = new PrismaClient();
      try {
        await prisma.$queryRaw`SELECT 1`;
        checks.database = { status: "ok", detail: "PostgreSQL connected" };
      } catch (err: unknown) {
        const message = err instanceof Error ? err.message : "Connection failed";
        checks.database = { status: "error", detail: `PostgreSQL: ${message}` };
      } finally {
        await prisma.$disconnect();
      }
    } else if (isSqlite) {
      // SQLite — check that the database file exists and is non-empty
      const dbPath = dbUrl.replace("file:", "").replace("./", "");
      const resolvedPath = path.isAbsolute(dbPath)
        ? dbPath
        : path.join(process.cwd(), dbPath);

      if (existsSync(resolvedPath)) {
        const stats = statSync(resolvedPath);
        checks.database = stats.size > 0
          ? { status: "ok", detail: `SQLite ${(stats.size / 1024).toFixed(1)} KB` }
          : { status: "error", detail: "Database file is empty" };
      } else {
        checks.database = { status: "error", detail: "Database file not found" };
      }
    } else {
      checks.database = { status: "error", detail: `Unrecognised DATABASE_URL scheme` };
    }
  } catch {
    checks.database = { status: "error", detail: "Cannot access database" };
  }

  // Backup check (only relevant for SQLite)
  if (isSqlite) {
    const backupDir = path.join(process.cwd(), "db", "backups");
    try {
      checks.backups = existsSync(backupDir)
        ? { status: "ok" }
        : { status: "degraded", detail: "No backup directory" };
    } catch {
      checks.backups = { status: "degraded" };
    }
  }

  // Firebase config check
  try {
    checks.firebase = !!process.env.NEXT_PUBLIC_FIREBASE_API_KEY
      ? { status: "ok" }
      : { status: "degraded" };
  } catch {
    checks.firebase = { status: "degraded" };
  }

  const allOk = Object.values(checks).every((c) => c.status === "ok");
  const hasErrors = Object.values(checks).some((c) => c.status === "error");

  return NextResponse.json({
    status: allOk ? "healthy" : hasErrors ? "unhealthy" : "degraded",
    version: "1.0.0",
    environment: process.env.NODE_ENV || "development",
    database: isPostgres ? "postgresql" : isSqlite ? "sqlite" : "unknown",
    timestamp: new Date().toISOString(),
    responseTime: `${Date.now() - startTime}ms`,
    checks,
  }, { status: hasErrors ? 503 : 200 });
}
