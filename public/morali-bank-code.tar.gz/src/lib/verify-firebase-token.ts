/**
 * Server-side Firebase ID token verification utility.
 * Uses Firebase Admin SDK to verify JWT tokens sent from the client.
 */

import { NextRequest, NextResponse } from "next/server";

// Lazy-load firebase-admin to avoid issues in client components
let adminAuth: ReturnType<typeof import("firebase-admin").auth> | null = null;

async function getAdminAuth() {
  if (!adminAuth) {
    try {
      const { getAuth: getAdminAuth } = await import("firebase-admin/auth");
      const { initializeApp: initAdminApp, getApp: getAdminApp, cert } = await import("firebase-admin/app");

      const app = getAdminApp("morali-admin") || initAdminApp("morali-admin", {
        credential: cert({
          projectId: "banque-digitale",
          clientEmail: process.env.FIREBASE_CLIENT_EMAIL || "",
          privateKey: (process.env.FIREBASE_PRIVATE_KEY || "").replace(/\\n/g, "\n"),
        }),
      });
      adminAuth = getAdminAuth(app);
    } catch {
      // Firebase Admin not configured — return null (auth will be optional for dev)
      return null;
    }
  }
  return adminAuth;
}

export interface VerifiedUser {
  uid: string;
  email: string | null;
}

/**
 * Verify a Firebase ID token from the Authorization header.
 * Returns the decoded user info, or null if invalid/unauthenticated.
 */
export async function verifyAuthToken(req: NextRequest): Promise<VerifiedUser | null> {
  try {
    const authHeader = req.headers.get("authorization");
    if (!authHeader?.startsWith("Bearer ")) return null;

    const idToken = authHeader.slice(7);
    if (!idToken) return null;

    const auth = await getAdminAuth();
    if (!auth) {
      // Admin SDK not configured — allow request in dev mode
      // In production, this would return null
      console.warn("[SECURITY] Firebase Admin not configured — auth verification skipped");
      return null;
    }

    const decoded = await auth.verifyIdToken(idToken);
    return {
      uid: decoded.uid,
      email: decoded.email || null,
    };
  } catch {
    return null;
  }
}

/**
 * Create an unauthorized response.
 */
export function unauthorizedResponse(message = "Non autorisé") {
  return NextResponse.json({ error: message }, { status: 401 });
}
