#!/bin/bash
# Pre-deployment checklist
echo "🔍 Morali Bank - Pre-deployment Check"
echo "======================================"
echo ""

# Check 1: Environment variables
echo "1️⃣  Environment Variables:"
if [ -n "$DATABASE_URL" ]; then
  echo "   ✅ DATABASE_URL is set"
  echo "$DATABASE_URL" | grep -q "postgresql://" && echo "   ✅ Using PostgreSQL" || echo "   ⚠️  Still using SQLite"
else
  echo "   ❌ DATABASE_URL is not set"
fi

if [ -n "$GOOGLE_APPLICATION_CREDENTIALS" ]; then
  echo "   ✅ GOOGLE_APPLICATION_CREDENTIALS is set"
else
  echo "   ⚠️  GOOGLE_APPLICATION_CREDENTIALS is not set (JWT verification will use fallback)"
fi

# Check 2: Prisma schema
echo ""
echo "2️⃣  Prisma Schema:"
if grep -q 'provider = "postgresql"' prisma/schema.prisma 2>/dev/null; then
  echo "   ✅ Using PostgreSQL schema"
elif grep -q 'provider = "sqlite"' prisma/schema.prisma 2>/dev/null; then
  echo "   ⚠️  Still using SQLite schema (run: cp prisma/schema.postgresql.prisma prisma/schema.prisma)"
else
  echo "   ❌ Cannot determine schema provider"
fi

# Check 3: Build
echo ""
echo "3️⃣  Build Check:"
if bun run build 2>/dev/null; then
  echo "   ✅ Build successful"
else
  echo "   ❌ Build failed"
fi

echo ""
echo "======================================"
echo "✅ Check complete!"
