# Morali Bank - Guide de Configuration Production

## Ce que tu dois faire MAINTENANT

Tu as presque tout ! Il manque juste 2 petites choses pour finaliser la connexion Supabase :

### 1. Trouver ton mot de passe Supabase

La chaîne de connexion que tu m'as envoyée contient `[YOUR-PASSWORD]` — c'est un placeholder. Voici comment trouver le vrai mot de passe :

1. Va sur **https://supabase.com/dashboard**
2. Sélectionne ton projet
3. Clique sur **Settings** (icône ⚙️ en bas à gauche)
4. Clique sur **Database** dans le menu
5. Regarde **"Database password"** — si tu ne t'en souviens pas, clique **"Reset database password"**
6. Copie le **nouveau mot de passe**
7. Dans le fichier **`.env.production`**, remplace `[YOUR-PASSWORD]` par ce mot de passe

La ligne finale doit ressembler à :
```
DATABASE_URL="postgresql://postgres:VOTRE_VRAI_MOT_DE_PASSE@db.ytyibgksbwpjukmlzqbx.supabase.co:5432/postgres"
```

### 2. Configurer la clé Firebase Admin SDK

Tu as envoyé la clé dans la session précédente. Voici comment l'installer :

1. Ouvrir le fichier **`service-account-key.json`** (à la racine du projet)
2. Remplacer le contenu avec le JSON complet que Firebase t'a donné (qui contient la vraie `private_key`)
3. C'est tout ! Le code va automatiquement la charger

### 3. Lancer la migration

Quand les 2 étapes ci-dessus sont faites, exécuter :

```bash
# 1. Installer la dépendance PostgreSQL
npm install pg

# 2. Copier le schema PostgreSQL
cp prisma/schema.postgresql.prisma prisma/schema.prisma

# 3. Générer le client Prisma
npx prisma generate

# 4. Pousser le schema vers Supabase
DATABASE_URL="postgresql://postgres:TON_MOT_DE_PASSE@db.ytyibgksbwpjukmlzqbx.supabase.co:5432/postgres" npx prisma db push
```

### 4. Vérifier que ça marche

```bash
curl https://[TON-DOMAINE]/api/health
```

Doit retourner :
```json
{
  "status": "healthy",
  "database": "postgresql",
  "auth": "admin_sdk"
}
```

---

## Déploiement sur Vercel (recommandé)

1. Pousser le code sur GitHub
2. Aller sur **https://vercel.com** → "Add New Project" → Importer le repo
3. Dans **Settings → Environment Variables**, ajouter TOUTES les variables de `.env.production`
4. Déployer
5. HTTPS est automatique avec Vercel !

## Fichiers importants

| Fichier | Description |
|---------|-------------|
| `.env` | Dev: SQLite local |
| `.env.production` | Prod: Supabase PostgreSQL + Firebase Admin |
| `service-account-key.json` | Clé Firebase Admin SDK (à remplir) |
| `prisma/schema.prisma` | Schema actuel (SQLite) |
| `prisma/schema.postgresql.prisma` | Schema pour production (PostgreSQL) |

## Checklist

- [ ] Remplacer `[YOUR-PASSWORD]` dans `.env.production`
- [ ] Remplacer `[REPLACE_WITH_YOUR_ACTUAL_PRIVATE_KEY]` dans `service-account-key.json`
- [ ] Lancer `npx prisma db push` vers Supabase
- [ ] Vérifier `/api/health` retourne `"database": "postgresql"`
- [ ] Déployer sur Vercel avec les variables d'environnement
- [ ] Tester: login, virement, dépôt, retrait
