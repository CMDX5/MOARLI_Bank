import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { rateLimit, getClientId } from "@/lib/rate-limit";
import { requireAuth } from "@/lib/auth-verify";

export async function POST(req: NextRequest) {
  // Rate limit
  const clientId = getClientId(req);
  const rl = rateLimit(`notif:create:${clientId}`, { maxRequests: 30, windowSec: 60 });
  if (!rl.allowed) {
    return NextResponse.json(
      { error: "Trop de requêtes. Réessayez plus tard." },
      { status: 429, headers: { "Retry-After": String(Math.ceil((rl.resetAt - Date.now()) / 1000)) } }
    );
  }

  // Auth
  const auth = await requireAuth(req);
  if (auth.error) return auth.error;

  try {
    const body = await req.json();
    const { uid, title, time, badge, badgeClass, icon, bg } = body;

    if (!uid || !title) {
      return NextResponse.json({ error: "Champs requis manquants" }, { status: 400 });
    }

    // Ownership: user can only create notifications for themselves
    if (uid !== auth.uid) {
      return NextResponse.json({ error: "Non autorisé" }, { status: 403 });
    }

    const notif = await db.notificationRecord.create({
      data: {
        uid: String(uid),
        title: String(title).slice(0, 200),
        time: String(time || "À l'instant"),
        badge: String(badge || "Info"),
        badgeClass: String(badgeClass || "nb-blue"),
        icon: String(icon || "bell"),
        bg: String(bg || "rgba(59,130,246,0.12)"),
        read: false,
      },
    });

    return NextResponse.json({ success: true, id: notif.id });
  } catch {
    return NextResponse.json({ error: "Erreur interne" }, { status: 500 });
  }
}
