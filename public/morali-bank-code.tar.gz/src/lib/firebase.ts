import { getApp, getApps, initializeApp } from "firebase/app";
import { getAnalytics, isSupported } from "firebase/analytics";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
// Firebase Storage removed — not used in the application

const firebaseConfig = {
  apiKey: "AIzaSyBTgQjc1zJvPSAZZ0VDZD0PLZRPFCw9Zlc",
  authDomain: "banque-digitale.firebaseapp.com",
  projectId: "banque-digitale",
  storageBucket: "banque-digitale.firebasestorage.app",
  messagingSenderId: "1082571970554",
  appId: "1:1082571970554:web:41b0f5d74fbc025f73b643",
  measurementId: "G-JXJ3D2M3K6",
};

export const isFirebaseConfigured = true;

const app = getApps().length ? getApp() : initializeApp(firebaseConfig);

let analyticsPromise: Promise<ReturnType<typeof getAnalytics> | null> | null = null;

if (typeof window !== "undefined") {
  analyticsPromise = isSupported()
    .then((supported) => (supported ? getAnalytics(app) : null))
    .catch(() => null);
}

export const firebaseApp = app;
export const firebaseAuth = getAuth(app);
export const firebaseDb = getFirestore(app);
// Firebase Storage removed — not used in the application
// export const firebaseStorage = getStorage(app);
export const firebaseAnalytics = analyticsPromise;

export { firebaseConfig };
