import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { rateLimit, getClientId } from "@/lib/rate-limit";
import { requireAuth } from "@/lib/auth-verify";

export async function POST(req: NextRequest) {
  // Rate limit
  const clientId = getClientId(req);
  const rl = rateLimit(`admin:log:${clientId}`, { maxRequests: 30, windowSec: 60 });
  if (!rl.allowed) {
    return NextResponse.json({ error: "Trop de requêtes" }, {
      status: 429,
      headers: { "Retry-After": String(Math.ceil((rl.resetAt - Date.now()) / 1000)) },
    });
  }

  // Auth
  const auth = await requireAuth(req);
  if (auth.error) return auth.error;
  if (!auth.uid) return NextResponse.json({ error: "Non autorisé" }, { status: 401 });

  try {
    const body = await req.json();
    const { action, details } = body;
    if (!action) {
      return NextResponse.json({ error: "Action requise" }, { status: 400 });
    }

    await db.adminActivity.create({
      data: {
        action: String(action).slice(0, 100),
        details: String(details || "").slice(0, 500),
      },
    });

    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Erreur interne" }, { status: 500 });
  }
}

export async function GET(req: NextRequest) {
  // Rate limit
  const clientId = getClientId(req);
  const rl = rateLimit(`admin:log:get:${clientId}`, { maxRequests: 60, windowSec: 60 });
  if (!rl.allowed) {
    return NextResponse.json({ error: "Trop de requêtes" }, {
      status: 429,
      headers: { "Retry-After": String(Math.ceil((rl.resetAt - Date.now()) / 1000)) },
    });
  }

  // Auth
  const auth = await requireAuth(req);
  if (auth.error) return auth.error;
  if (!auth.uid) return NextResponse.json({ error: "Non autorisé" }, { status: 401 });

  try {
    const limit = Math.min(Number(req.nextUrl.searchParams.get("limit") || 50), 200);
    const logs = await db.adminActivity.findMany({
      orderBy: { timestamp: "desc" },
      take: limit,
    });
    return NextResponse.json({ logs });
  } catch {
    return NextResponse.json({ logs: [] }, { status: 200 });
  }
}
