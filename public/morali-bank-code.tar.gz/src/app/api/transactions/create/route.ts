import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { rateLimit, getClientId } from "@/lib/rate-limit";
import { requireAuth } from "@/lib/auth-verify";

export async function POST(req: NextRequest) {
  // Rate limit
  const clientId = getClientId(req);
  const rl = rateLimit(`tx:create:${clientId}`, { maxRequests: 30, windowSec: 60 });
  if (!rl.allowed) {
    return NextResponse.json(
      { error: "Trop de requêtes. Réessayez plus tard." },
      { status: 429, headers: { "Retry-After": String(Math.ceil((rl.resetAt - Date.now()) / 1000)) } }
    );
  }

  // Auth
  const auth = await requireAuth(req);
  if (auth.error) return auth.error;

  try {
    const body = await req.json();
    const {
      uid, receiptId, senderUid, senderMoraliId, senderName,
      recipientUid, recipientMoraliId, recipientName,
      amount, fees, type, status, destination,
    } = body;

    if (!receiptId || !senderUid || !recipientUid || !amount) {
      return NextResponse.json({ error: "Champs requis manquants" }, { status: 400 });
    }

    // Ownership: user can only create transactions for themselves
    if (senderUid !== auth.uid) {
      return NextResponse.json({ error: "Non autorisé" }, { status: 403 });
    }

    // Idempotency: check if transaction with this receiptId already exists
    const existing = await db.transactionRecord.findFirst({
      where: { receiptId: String(receiptId) },
    });
    if (existing) {
      return NextResponse.json({ success: true, id: existing.id, duplicate: true });
    }

    const tx = await db.transactionRecord.create({
      data: {
        receiptId: String(receiptId),
        senderUid: String(senderUid),
        senderMoraliId: String(senderMoraliId || ""),
        senderName: String(senderName || "Utilisateur"),
        recipientUid: String(recipientUid),
        recipientMoraliId: String(recipientMoraliId || ""),
        recipientName: String(recipientName || "Utilisateur"),
        amount: Number(amount) || 0,
        fees: Number(fees) || 0,
        type: String(type || "virement"),
        status: String(status || "success"),
        destination: destination ? String(destination) : null,
      },
    });

    return NextResponse.json({ success: true, id: tx.id });
  } catch {
    return NextResponse.json({ error: "Erreur interne" }, { status: 500 });
  }
}
