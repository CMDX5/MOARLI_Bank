import { NextResponse } from "next/server";
import { mkdir, copyFile, readdir, unlink } from "fs/promises";
import { existsSync, statSync } from "fs";
import path from "path";

const BACKUP_DIR = path.join(process.cwd(), "db", "backups");
const DB_PATH = path.join(process.cwd(), "db", "custom.db");
const MAX_BACKUPS = 10;

/**
 * POST /api/backup — Create a SQLite database backup.
 */
export async function POST() {
  try {
    if (!existsSync(BACKUP_DIR)) {
      await mkdir(BACKUP_DIR, { recursive: true });
    }

    if (!existsSync(DB_PATH)) {
      return NextResponse.json({ error: "Base de données introuvable" }, { status: 404 });
    }

    const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
    const backupFile = path.join(BACKUP_DIR, `morali-backup-${timestamp}.db`);

    await copyFile(DB_PATH, backupFile);

    const size = existsSync(backupFile) ? statSync(backupFile).size : 0;

    // Cleanup old backups
    try {
      const files = await readdir(BACKUP_DIR);
      const backups = files
        .filter((f) => f.startsWith("morali-backup-") && f.endsWith(".db"))
        .sort()
        .reverse();
      for (const old of backups.slice(MAX_BACKUPS)) {
        try { await unlink(path.join(BACKUP_DIR, old)); } catch {}
      }
    } catch {}

    return NextResponse.json({ success: true, timestamp, size });
  } catch {
    return NextResponse.json({ error: "Erreur lors de la sauvegarde" }, { status: 500 });
  }
}

/**
 * GET /api/backup — Returns backup status.
 */
export async function GET() {
  try {
    const hasDb = existsSync(DB_PATH);
    const dbSize = hasDb ? statSync(DB_PATH).size : 0;

    let backups: string[] = [];
    if (existsSync(BACKUP_DIR)) {
      const files = await readdir(BACKUP_DIR);
      backups = files
        .filter((f) => f.startsWith("morali-backup-") && f.endsWith(".db"))
        .sort()
        .reverse();
    }

    return NextResponse.json({
      database: { exists: hasDb, size: dbSize },
      backups: backups.length,
      lastBackup: backups[0] || null,
    });
  } catch {
    return NextResponse.json({ error: "Erreur interne" }, { status: 500 });
  }
}
