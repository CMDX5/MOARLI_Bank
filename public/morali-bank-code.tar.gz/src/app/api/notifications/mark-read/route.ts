import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { rateLimit, getClientId } from "@/lib/rate-limit";
import { requireAuth } from "@/lib/auth-verify";

export async function POST(req: NextRequest) {
  // Rate limit
  const clientId = getClientId(req);
  const rl = rateLimit(`notif:markread:${clientId}`, { maxRequests: 30, windowSec: 60 });
  if (!rl.allowed) {
    return NextResponse.json(
      { error: "Trop de requêtes. Réessayez plus tard." },
      { status: 429, headers: { "Retry-After": String(Math.ceil((rl.resetAt - Date.now()) / 1000)) } }
    );
  }

  // Auth
  const auth = await requireAuth(req);
  if (auth.error) return auth.error;

  try {
    const body = await req.json();
    const { id, uid, markAll } = body;

    if (markAll && uid) {
      // Ownership: user can only mark their own notifications
      if (uid !== auth.uid) {
        return NextResponse.json({ error: "Non autorisé" }, { status: 403 });
      }

      await db.notificationRecord.updateMany({
        where: { uid: String(uid) },
        data: { read: true },
      });
      return NextResponse.json({ success: true });
    }

    if (!id) {
      return NextResponse.json({ error: "ID requis" }, { status: 400 });
    }

    // Ownership check: verify the notification belongs to this user
    const notif = await db.notificationRecord.findUnique({
      where: { id: String(id) },
      select: { uid: true },
    });
    if (!notif || notif.uid !== auth.uid) {
      return NextResponse.json({ error: "Non autorisé" }, { status: 403 });
    }

    await db.notificationRecord.update({
      where: { id: String(id) },
      data: { read: true },
    });

    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Erreur interne" }, { status: 500 });
  }
}
