/**
 * Secure PIN hashing utilities.
 * Uses SHA-256 via Web Crypto API (client) or Node crypto (server).
 * 
 * Security notes:
 * - PINs are hashed before storage (never plaintext)
 * - Uses per-user salt (uid-based) to prevent rainbow table attacks
 * - Timing-safe comparison to prevent timing attacks
 */

// Cache for dynamically imported crypto module (Node.js only)
let cachedTimingSafeEqual: ((a: Buffer, b: Buffer) => boolean) | null = null;

/**
 * Hash a PIN with a salt using SHA-256.
 * Works in both browser (Web Crypto) and Node.js (crypto).
 */
export async function hashPin(pin: string, salt: string): Promise<string> {
  const combined = `${salt}:${pin}`;

  if (typeof window !== "undefined" && window.crypto?.subtle) {
    // Browser environment
    const encoder = new TextEncoder();
    const data = encoder.encode(combined);
    const hashBuffer = await window.crypto.subtle.digest("SHA-256", data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
  }

  // Node.js environment (API routes)
  const { createHash } = await import("crypto");
  return createHash("sha256").update(combined).digest("hex");
}

/**
 * Verify a PIN against a stored hash.
 * Uses timing-safe comparison to prevent timing attacks.
 */
export async function verifyPin(pin: string, salt: string, storedHash: string): Promise<boolean> {
  const computedHash = await hashPin(pin, salt);
  return timingSafeEqual(computedHash, storedHash);
}

/**
 * Timing-safe string comparison.
 * Prevents timing attacks by comparing all characters regardless of early mismatch.
 */
function timingSafeEqual(a: string, b: string): boolean {
  if (typeof Buffer !== "undefined") {
    // Node.js — use crypto.timingSafeEqual
    const bufA = Buffer.from(a, "utf8");
    const bufB = Buffer.from(b, "utf8");
    if (bufA.length !== bufB.length) return false;

    // Lazy-load timingSafeEqual
    if (!cachedTimingSafeEqual) {
      try {
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        const crypto = require("crypto");
        cachedTimingSafeEqual = crypto.timingSafeEqual;
      } catch {
        return constantTimeCompare(a, b);
      }
    }
    return cachedTimingSafeEqual(bufA, bufB);
  }

  // Browser fallback
  return constantTimeCompare(a, b);
}

/**
 * Constant-time string comparison (browser-safe fallback).
 * Iterates through all characters regardless of mismatch position.
 */
function constantTimeCompare(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let result = 0;
  for (let i = 0; i < a.length; i++) {
    result |= a.charCodeAt(i) ^ b.charCodeAt(i);
  }
  return result === 0;
}

/**
 * Generate a random salt for PIN hashing.
 */
export function generatePinSalt(): string {
  if (typeof window !== "undefined" && window.crypto?.getRandomValues) {
    const array = new Uint8Array(16);
    window.crypto.getRandomValues(array);
    return Array.from(array).map((b) => b.toString(16).padStart(2, "0")).join("");
  }

  // Node.js fallback — use synchronous crypto
  const { randomBytes } = await_import_node_crypto();
  return randomBytes(16).toString("hex");
}

/**
 * Synchronous import helper for Node.js crypto.
 * Uses require() since this is server-only code.
 */
// eslint-disable-next-line @typescript-eslint/no-require-imports
const await_import_node_crypto = () => require("crypto");
