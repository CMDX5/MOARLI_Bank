# Morali Bank - Setup Script (Windows PowerShell)
# Execute ce script dans le dossier MOARLI-BANK

Write-Host "=== Morali Bank - Installation ===" -ForegroundColor Cyan

# 1. Installer les dependances
Write-Host "`n[1/3] Installation de Next.js et dependances..." -ForegroundColor Yellow
npm install next@latest react@latest react-dom@latest typescript@latest @types/react@latest @types/node@latest
npm install tailwindcss @tailwindcss/postcss postcss autoprefixer
npm install @prisma/client prisma pg better-sqlite3 firebase firebase-admin qrcode.react jsqr
npm install lucide-react clsx tailwind-merge class-variance-authority

# 2. Generer le client Prisma
Write-Host "`n[2/3] Generation Prisma..." -ForegroundColor Yellow
npx prisma generate

Write-Host "`n=== Installation terminee ===" -ForegroundColor Green
Write-Host "`nProchaine etape: deploiement sur Vercel" -ForegroundColor Cyan
Write-Host "1. Aller sur https://vercel.com" -ForegroundColor White
Write-Host "2. Importer le repo GitHub: CMDX5/MOARLI-BANK" -ForegroundColor White
Write-Host "3. Ajouter les variables d'environnement" -ForegroundColor White
